# Changelog

---

## [V1.5] — 2025 — Hotel Door Logic

### Hardware Change
- **GPIO 17 freed from RFID RST** — move the wire from RC522 RST pin to the 3.3V rail. The chip held HIGH = permanently active. RFID works identically with no code change needed.
- **IR obstacle sensor on GPIO 17** — detects whether the door is physically open or closed. `INPUT_PULLUP` mode: if sensor is disconnected, pin reads HIGH (door "open") → timer frozen → bolt never fires autonomously. Safe fail-open behaviour.

### Added
- **Hotel Door Logic** — replaces the previous blind timer with 3-state smart lock:

  | State | Behaviour |
  |-------|-----------|
  | Unlocked, door not opened | Timer runs → locks after `cfg_doorRelockMs` |
  | Unlocked, door swung open | Timer frozen indefinitely while door is open |
  | Door swings shut | Timer starts → locks after `cfg_doorRelockMs` |

- **IR sensor invert toggle** — web Config tab → RFID & Door section. Tick if your IR module reads reversed (HIGH = detected instead of LOW). Stored in flash key `irdinv`. No re-flash needed.
- **Door status card** on dashboard — live 3-state display:
  - 🟢 LOCKED — deadbolt engaged
  - 🟠 OPEN — relay de-energised, door physically open (timer frozen)
  - 🔵 CLOSED — relay de-energised, door in frame, counting down to lock
- `dir` field added to `/api/state` JSON (boolean: IR door closed state)
- `/status` Telegram command now shows door lock state + IR physical state

### Changed
- Door auto-lock now uses `cfg_doorRelockMs` (configurable) throughout — no hardcoded `DOOR_RELOCK_MS` constant used in loop logic

---

## [V1.4] — 2025

### Added
- **Configurable door lock timer** — door auto-lock delay (1–60 seconds) now set from web Config tab → RFID section. Stored in flash key `drl`.
- **Dynamic unlock button** — dashboard "Unlock Door" button label updates to show the configured duration, e.g. "Unlock Door (5s)".

---

## [V1.3] — 2025

### Added
- **LDR dark threshold** — configurable from web UI (0–4095 ADC). Defines how dark the room must be before PIR motion triggers the light. Stored in flash key `ldrd`.
- **Intrusion alert distance** — configurable ultrasonic alarm distance (1–400 cm). Stored in flash key `dsta`.
- **LCD wake distance** — configurable presence detection range for LCD backlight (1–400 cm). Stored in flash key `lcdw`.
- **LCD sleep timer** — configurable screen-off delay (0–3600 seconds). Setting 0 keeps LCD permanently on. Stored in flash key `lcds`.

All four settings exposed in web Config → Advanced Sensor Tuning section with live current-value hints.

---

## [V1.2] — 2025

### Added
- **Per-alert Telegram toggles** — 7 independent checkboxes in web Config → Telegram section:
  - Motion Detected (PIR)
  - High Temperature / Fan Auto-ON
  - Dry Soil Alert
  - Gas / Smoke Alert
  - Intrusion Alert
  - RFID Access / Denied
  - Pump Auto-Cycles

  All events still recorded in web event log regardless of Telegram setting.
  Stored in flash keys `a_mot`, `a_tmp`, `a_soi`, `a_gas`, `a_dst`, `a_rfd`, `a_pmp`.

---

## [V1.1] — 2025

### Added
- **Configurable fan temperature threshold** — removed hardcoded 32°C. Web Config → Climate section with 10–60°C range. Stored in flash key `tth`.

---

## [V1.0] — 2025 — Initial Public Release

First public release. Based on private development build V10.4. All personal identifiers removed. Project named Guava Home.

### Added
- Telegram auto-status at configurable interval (minutes, 0 = disabled). Flash key `tgi`.
- Configurable Telegram poll interval (2–60 seconds). Flash key `tgpms`.
- Configurable pump ON/OFF cycle durations (seconds). Flash keys `pon`, `poff`.
- Configurable soil dry threshold (1000–4095 ADC). Flash key `sdt`.
- Clap count tracked since boot, shown in `/status` output.
- Garden & Pump section and Telegram Automation section in web Config tab.
- Dynamic soil card colour in dashboard — updates instantly when threshold changes.

### Fixed (inherited OTA bugs, resolved before V1.0 publish)
- **ISR edge RISING → FALLING** — KY-037 DO goes LOW on sound. RISING never fired. Critical.
- **Auto-status immediate fire** — `tTGStatus` now initialised to `millis()` after WiFi connects.
- **Motion not in event log** — `logEvent("Motion detected")` restored.
- **Door lock not logged** — `logEvent("Door locked")` added to `lockDoor()`.
- **OTA blocks relay automation** — `if (otaActive) return;` in loop.
- **Pump fires immediately on boot** — `pump.phaseStart = millis()` set in setup.

### Changed from development build
- Project name: Guava Home
- AP network: `Guava_Setup`
- OTA hostname: `GuavaHome` | default password: `guavahome`
- Flash namespace: `gh`
- All personal identifiers removed from firmware, UI, and boot messages

### Inherited from V10.4 (development)
- OTA firmware updates — ArduinoOTA + browser /update page
- KY-037 hardware interrupt clap sensor (IRAM_ATTR, 1500ms acoustic debounce)
- MQ-2 gas sensor on GPIO36 (1kΩ/2kΩ voltage divider)
- HC-SR04 pin swap: TRIG=12, ECHO=13 (boot-crash fix)
- Dynamic RFID access control — 3 user slots, web UI, flash-backed
- Live last-scanned UID on Config tab
- PIR daylight-aware lighting (motion + dark room required)
- Configurable PIR light-off delay
- 4-page LCD with physical button
- LCD text scrolling, ultrasonic LCD wake
- Soil ADC inverted logic (dry=HIGH, wet=LOW)
- AP rescue mode — 10-minute self-destruct
- IST time sync (UTC+5:30)
- All settings via Preferences.h — no re-flash needed

---

## OTA Fix History (applied before V1.0)

| Bug | Symptom | Root Cause | Fix |
|-----|---------|-----------|-----|
| Browser OTA double response | Upload hangs at 100% or blank page | `webServer.send()` in upload handler AND completion handler — double send on one socket | Removed all `send()` from upload handler; response now only in completion handler |
| Browser OTA failure path crash | HTTP stream corrupt on failed update | Failed update: upload handler sent 500, completion handler sent 200 → double response | Same fix — completion handler checks `Update.hasError()` for both paths |
| IDE OTA "No response from device" | Intermittent, worse with Telegram active | `tlsClient.setTimeout(15)` — Telegram poll blocked loop for up to 15s; ArduinoOTA handshake times out in ~1s | Reduced to `setTimeout(5)` |
| IDE OTA mid-transfer dropout | Upload starts then silently fails | Same blocking issue during transfer — ArduinoOTA TCP connection dropped | Same fix |
| `Update.begin()` silent failure | Update appeared to succeed but ESP booted old firmware | Return value of `Update.begin()` was ignored — errors went undetected | Now checked; error printed to Serial |
| Browser OTA blank success page | Page showed blank after successful flash | `ESP.restart()` called with 1s delay — TCP not flushed | Increased to 2000ms delay in completion handler; auto-redirect JS added |
