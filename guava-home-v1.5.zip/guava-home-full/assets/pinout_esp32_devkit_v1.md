# ESP32 DevKit V1 — Pin Reference for Guava Home

## Pin Allocation

```
                    ┌──────────────┐
              EN ───┤              ├─── IO23  MOSI → RFID
           IO36 ─── MQ-2 (AOUT)   ├─── IO22  SCL  → LCD
           IO39 ─── KY-037 (DO)   ├─── IO21  SDA  → LCD
           IO34 ─── LDR            ├─── IO19  MISO ← RFID
           IO35 ─── BTN2 (page)   ├─── IO18  SCK  → RFID
           IO32 ─── Soil AOUT     ├─── IO5   SS   → RFID
           IO33 ─── RELAY4/Pump   ├─── IO17  RST  → RFID
           IO25 ─── RELAY3/Door   ├─── IO16  RELAY2/Light
           IO26 ─── BTN1/Exit     ├─── IO4   DHT11
           IO27 ─── PIR           ├─── IO2   Inbuilt LED
           IO14 ─── BUZZER        ├─── IO15  RELAY1/Fan
           IO12 ─── TRIG          ├─── IO13  ECHO (via divider)
             GND ───              ├─── GND
             VIN ───┤              ├─── 3V3
                    └──────────────┘
```

## Pin Properties

| GPIO | Input/Output | ADC | Notes |
|------|-------------|-----|-------|
| 2 | Both | ADC2 (no WiFi) | Inbuilt LED |
| 4 | Both | ADC2 (no WiFi) | DHT11 |
| 5 | Both | — | RFID SS; SPI CS |
| 12 | Both | ADC2 (no WiFi) | HC-SR04 TRIG; strapping pin — idles LOW |
| 13 | Both | ADC2 (no WiFi) | HC-SR04 ECHO (via divider) |
| 14 | Both | ADC2 (no WiFi) | Buzzer |
| 15 | Both | ADC2 (no WiFi) | RELAY1 Fan |
| 16 | Both | — | RELAY2 Light |
| 17 | Both | — | RFID RST |
| 18 | Both | — | SPI SCK |
| 19 | Both | — | SPI MISO |
| 21 | Both | — | I2C SDA |
| 22 | Both | — | I2C SCL |
| 23 | Both | — | SPI MOSI |
| 25 | Both | DAC1 | RELAY3 Door |
| 26 | Both | DAC2 | BTN1 Exit |
| 27 | Both | ADC2 (no WiFi) | PIR |
| 32 | Both | ADC1 ✓ | Soil Moisture |
| 33 | Both | ADC1 ✓ | RELAY4 Pump |
| 34 | Input only | ADC1 ✓ | LDR — no pull-up/down |
| 35 | Input only | ADC1 ✓ | BTN2 page — no pull-up/down |
| 36 | Input only | ADC1 ✓ | MQ-2 AOUT — no pull-up/down |
| 39 | Input only | ADC1 ✓ | KY-037 DO — no pull-up/down |

## ADC Notes

- **ADC2** is disabled when WiFi is active — do not use GPIOs 0, 2, 4, 12–15, 25–27 for analog when WiFi is running
- All analog sensors in Guava Home use **ADC1** (GPIOs 32–39) — safe with WiFi
- ADC resolution: 12-bit (0–4095)
- ADC reference: 3.3V (4095 = 3.3V input)

## Reserved Pins (never use)

| GPIO | Reserved |
|------|---------|
| 1 | UART0 TX (Serial Monitor) |
| 3 | UART0 RX (Serial Monitor) |
| 6–11 | Internal SPI flash — using these causes crash |
