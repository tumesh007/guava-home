# Troubleshooting

---

## Upload & Compilation

| Problem | Fix |
|---------|-----|
| `Connecting........_____` stuck | Hold BOOT button while clicking Upload, release on "Connecting..." |
| ArduinoJson errors | Install v6.x specifically — not v7 |
| `NimBLEDevice.h` not found | Wrong firmware version — this build has no BLE |
| `Huge App` partition required | Wrong — use **Default 4MB with spiffs** |
| Compilation fails with no message | Check all 6 libraries are installed |

---

## OTA — IDE (ArduinoOTA)

| Problem | Fix |
|---------|-----|
| GuavaHome not in network ports | ESP32 not connected to WiFi; check LCD Page 4 |
| "No response from device" | Telegram poll was blocking the loop; retry upload immediately; or temporarily increase poll interval to 60s |
| Password prompt appears, then fails | Wrong OTA password; check Config tab → OTA Password field |
| Upload starts, then drops mid-way | Weak WiFi signal between PC and ESP32; move closer |
| Works sometimes but not reliably | Reduce Telegram poll interval (raise seconds value) |

**Root cause note:** Telegram's TLS connection can block the main loop for 2–5 seconds per poll. ArduinoOTA handshake has a ~1s window. If timing is bad, OTA misses the window. Reducing the poll interval and retrying upload usually resolves it.

---

## OTA — Browser (/update page)

| Problem | Fix |
|---------|-----|
| Page loads but Upload button does nothing | Wrong file format — select a `.bin` file, not `.ino` |
| "Update FAILED" in red | Wrong `.bin` — must match partition scheme (Default 4MB) |
| Upload stuck at 100%, no response | Fixed in V1.4 — update to V1.4 firmware via USB first |
| Page shows blank after upload | Fixed in V1.4 — success page now auto-redirects in 12 seconds |
| How to get the `.bin` file | Arduino IDE → Sketch → Export Compiled Binary |

---

## WiFi & Network

| Problem | Fix |
|---------|-----|
| Never connects to home WiFi | Check SSID is case-sensitive correct; try 2.4GHz band (not 5GHz) |
| Guava_Setup AP not visible | Wait 30 seconds after boot; if still missing, press EN button on ESP32 |
| IP changes every reboot | Set DHCP reservation on router for ESP32's MAC address |
| Web dashboard loads but stops updating | Browser cache issue — hard refresh (Ctrl+Shift+R) |
| Dashboard works but Telegram doesn't | Check bot token and Chat ID in Config tab |

---

## LCD

| Problem | Fix |
|---------|-----|
| Blank screen | Adjust contrast pot on I2C backpack; or try `0x3F` instead of `0x27` |
| Solid black blocks | Contrast too high — turn pot slowly counter-clockwise |
| Screen never sleeps | Set LCD Sleep Timer in Config → Advanced (0 = always on is intentional) |
| LCD doesn't wake on approach | Ultrasonic sensor not working — check 5V supply and voltage divider wiring |

---

## Sensors

**DHT11**
| Problem | Fix |
|---------|-----|
| Always 0°C / 0% | Missing 4.7kΩ pull-up resistor between DATA and 3.3V |
| Reads NaN | Same — pull-up missing |

**PIR HC-SR501**
| Problem | Fix |
|---------|-----|
| Constant false triggers first 60s | Normal — firmware ignores PIR for 60s warm-up |
| Never triggers | Increase Sx sensitivity pot; check 5V supply |
| Triggers once, then pauses for minutes | Tx time delay pot too high — turn fully counter-clockwise |
| Light stays on after person leaves | Tx still too high, or PIR jumper on L (single trigger) — set to H |

**HC-SR04**
| Problem | Fix |
|---------|-----|
| Always reads 999 or 0 | Check 5V supply; verify voltage divider on ECHO (GPIO 13) |
| LCD never wakes | Same — or LCD Wake Distance set too low in Config → Advanced |

**KY-037 Clap Sensor**
| Problem | Fix |
|---------|-----|
| Light toggles randomly | Sensitivity too high — turn pot clockwise to reduce |
| Clap doesn't work at all | Check DO connected to GPIO 39; verify 5V supply |
| Double-toggle on one clap | Relay "snap" re-triggering — acoustic debounce is 1500ms; normal for very loud clicks |

**Soil Moisture**
| Problem | Fix |
|---------|-----|
| Always shows DRY even in water | Expected — ADC is inverted; high ADC = dry. Threshold in Config → Garden |
| Soil threshold not alerting | Lower the threshold value (e.g. 3000 → 2500) in Config → Garden |

**MQ-2 Gas**
| Problem | Fix |
|---------|-----|
| Always above 2000 ADC in clean air | Normal for first 30s warm-up; if persistent, re-calibrate — readings vary by unit |
| Never triggers | Check voltage divider on AOUT (GPIO 36); verify 5V supply |

---

## Relays

| Problem | Fix |
|---------|-----|
| Relay activates at boot | Boot glitch — always present before V1.0; update to V1.0+ |
| Relay clicks but load doesn't switch | Using NC terminal — switch wire to NO |
| All relays ON when should be OFF | Active LOW logic — LOW = ON is correct behaviour |

---

## Telegram

| Problem | Fix |
|---------|-----|
| Bot not responding | Check WiFi; verify bot token has no spaces |
| "Unauthorised" on every message | Chat ID wrong — message @userinfobot on Telegram |
| Very slow response | Increase Telegram poll interval in Config — response latency = poll interval |
| Auto-status fires immediately on boot | Fixed in V1.0 — upgrade firmware |

---

## RFID

| Problem | Fix |
|---------|-----|
| Card not detected | Check VCC is 3.3V (not 5V); verify all 5 SPI wires |
| UID shows as `00 00 00 00` | Partial read — wiring issue, check MISO/MOSI not swapped |
| Card detected but always DENIED | UID in Config tab uses uppercase — verify it matches exactly |
| How to add a new card | Scan card → UID appears in Config tab → copy into user slot → Save |

---

## First Boot / Factory Reset

**To erase all saved settings:**
Arduino IDE → Tools → Erase Flash → All Flash Contents → then re-upload firmware → follow First Boot guide.

---

## IR Door Sensor (V1.5)

| Problem | Fix |
|---------|-----|
| Door relocks while physically open | IR sensor logic is reversed — tick "IR sensor inverted" in Config → RFID & Door |
| Door never relocks even when closed | Same — untick the invert checkbox |
| Door card shows OPEN permanently | Sensor wired incorrectly, or disconnected — check OUT/D0 connected to GPIO 17 |
| RFID stopped working after V1.5 | Ensure RC522 RST wire was moved to 3.3V rail, not removed entirely |
| Door card always shows LOCKED | `dev.door` is false (relay not unlocked) — the IR state only displays when door is in unlocked state |
