# User Guide

*For family members and guests — no technical knowledge needed.*

---

## What Does This Do?

The small purple board with wires controls your home:
- **Fan** and **lights** — automatically and manually
- **Front door** — tap RFID card or press button to unlock
- **Water pump** — runs on a timer to water plants
- Monitors temperature, humidity, gas, motion, and soil moisture
- Sends alerts to Telegram and can be controlled remotely

---

## 🚪 Opening the Door

**Tap your RFID card** near the black scanner — hold still for 1 second.
- ✅ One beep + click = unlocked for the configured number of seconds
- ❌ Three beeps = unregistered card

**Exit button** — press the small button inside near the door.

**Telegram** — send `unlock` to the home bot from anywhere.

---

## 💡 Lights and Fan

**Automatic:**
- Light turns ON when it's dark and motion is detected
- Light turns OFF automatically after the configured delay when no motion
- Clap once to toggle the light manually (overrides automation)
- Fan turns ON automatically when temperature exceeds the configured threshold

**Manual via Telegram:**
```
light_on    light_off
fan_on      fan_off
```

**Manual via dashboard:** Open the web dashboard on any phone connected to home WiFi.

---

## 💧 Water Pump

The pump runs automatically on a cycle: ON for N seconds, then OFF for N seconds, repeating. Cycle times are configurable.

```
pump_auto   — start automatic cycle
pump_stop   — stop automatic cycle
pump_on     — turn on manually
pump_off    — turn off manually
```

---

## 📱 Web Dashboard

On any phone or computer connected to home WiFi:

1. Open a browser
2. Type the IP address shown on the small LCD screen
3. Dashboard opens showing live sensor readings and controls

The IP address is also sent via Telegram every time the system restarts.

**Install as app (Android):** Browser menu → Add to Home Screen. Opens full-screen like a native app.

---

## 📺 LCD Screen

The screen shows sensor data. It goes dark after 30 seconds (configurable) and wakes when you walk within range.

Press the small button on the side to cycle through 4 pages:

| Page | Shows |
|------|-------|
| 1 — Main | Temperature, humidity, scrolling status |
| 2 — Sensors | Light, soil, gas, distance |
| 3 — Devices | Fan, light, door, pump states |
| 4 — Network | WiFi status and IP address |

---

## 🔔 Telegram Alerts You'll Receive

| Message | Means |
|---------|-------|
| Motion detected | Someone entered the room |
| Temp high: X°C — Fan ON | Fan auto-started |
| Plant needs water | Soil is dry |
| GAS/SMOKE ALERT | MQ-2 sensor triggered |
| INTRUSION: Xcm | Something close to ultrasonic sensor |
| Access: [Name] | RFID door opened |
| DENIED + UID | Unknown card scanned |
| Pump ON — cycle N | Automatic watering started |

---

## 🆘 WiFi Rescue

If the router is replaced or password changes, the system creates a temporary WiFi:

**LCD shows:** `Setup: Guava / 192.168.4.1`

1. Connect phone to WiFi network: **Guava_Setup** (no password)
2. Open browser → `http://192.168.4.1`
3. Config tab → update WiFi name and password
4. Save & Reboot

The rescue network turns itself off after 10 minutes.

---

## ❓ Common Questions

**Screen is dark.** Walk close to the box — it wakes automatically. Or press the page button.

**Door didn't unlock with my card.** Hold card flat and still for 1 full second. If three beeps, card isn't registered — ask the admin to add it via Config tab.

**Lights keep turning on.** Motion sensor is detecting movement. You can turn automation off with `light_off` and use manual control.

**Telegram bot not responding.** Check the LCD Page 4 for WiFi status. If it shows "WiFi:Lost", the internet connection is down.

**Something smells and the fan turned on.** The temperature sensor triggered it automatically. The fan will turn off when the room cools below the threshold.
