# Wiring Reference

Complete connection guide for every component. Common GND shared by all.

> **Three rules before you wire anything:**
> 1. RFID RC522 is **3.3V only** — 5V destroys it permanently
> 2. HC-SR04 ECHO outputs **5V** — must go through voltage divider
> 3. Set relay pins HIGH in code before `pinMode()` — prevents boot glitch

---

## Voltage Dividers (replaces logic level converter for two signals)

Both dividers use the same resistor values: **1kΩ series + 2kΩ to GND**

```
Signal (5V) ── 1kΩ ── GPIO pin
                          │
                         2kΩ
                          │
                         GND

Output = 5V × 2/(1+2) = 3.33V  ← safe for ESP32
```

| Signal | GPIO | Divider needed? |
|--------|------|----------------|
| HC-SR04 ECHO | 13 | Yes — 5V output |
| MQ-2 AOUT | 36 | Yes — 5V output |
| All others | various | No |

---

## DHT11 — Temperature & Humidity

**GPIO 4 | 1-Wire | 3.3V**

| DHT11 pin | Connect to |
|-----------|-----------|
| VCC | 3.3V |
| DATA | GPIO 4 + 4.7kΩ pull-up to 3.3V |
| GND | GND |

> 4.7kΩ pull-up between DATA and 3.3V is mandatory — without it, readings are NaN.

---

## HC-SR04 — Ultrasonic Distance

**GPIO 12 (TRIG) + GPIO 13 (ECHO) | 5V sensor**

| HC-SR04 pin | Connect to |
|-------------|-----------|
| VCC | 5V |
| TRIG | GPIO 12 (direct — 3.3V signal is fine for TRIG) |
| ECHO | 1kΩ → GPIO 13 → 2kΩ → GND |
| GND | GND |

> GPIO 12 is a strapping pin. TRIG idles LOW (safe). ECHO was on GPIO 12 in earlier builds and caused boot crashes — this pin swap is permanent.

---

## PIR HC-SR501 — Motion Sensor

**GPIO 27 | Digital | 3.3V output — direct**

| PIR pin | Connect to |
|---------|-----------|
| VCC | 5V |
| OUT | GPIO 27 |
| GND | GND |

**Pot adjustments:**

| Pot | Name | Setting |
|-----|------|---------|
| Tx (right) | Time delay | Turn fully counter-clockwise (minimum ~3s hold) |
| Sx (left) | Sensitivity | Adjust to room size; clockwise = more range |
| Jumper | Trigger mode | H position (repeat trigger) |

---

## KY-037 — Clap / Sound Sensor

**GPIO 39 | Digital DO | Hardware interrupt FALLING edge**

| KY-037 pin | Connect to |
|------------|-----------|
| VCC | 5V |
| GND | GND |
| DO | GPIO 39 |
| AO | Not connected |

DO is normally HIGH (module pull-up), goes LOW on sound. No external resistor needed. Adjust onboard pot clockwise to reduce sensitivity (prevent constant triggering).

---

## MQ-2 — Gas / Smoke Sensor

**GPIO 36 | Analog ADC1 | 5V via divider**

| MQ-2 pin | Connect to |
|----------|-----------|
| VCC | 5V |
| GND | GND |
| AOUT | 1kΩ → GPIO 36 → 2kΩ → GND |
| DOUT | Not connected |

> Warm-up: MQ-2 needs ~30 seconds after power-on. Calibrate: clean air reads ~300–600 ADC. Default alarm threshold: 2000 ADC.

---

## LDR — Light Sensor

**GPIO 34 | Analog ADC1 | Input-only**

```
3.3V ── LDR ── GPIO 34
                  │
               10kΩ → GND
```

No polarity. Default dark threshold: ADC < 1000 (configurable from web UI).

---

## Soil Moisture Sensor

**GPIO 32 | Analog ADC1**

| Pin | Connect to |
|-----|-----------|
| VCC | 3.3V or 5V |
| GND | GND |
| AOUT | GPIO 32 |
| DOUT | Not connected |

**Inverted logic:** Dry soil → HIGH ADC (>3000). Wet soil → LOW ADC (<1000). Default dry threshold: 3000 (configurable from web UI).

---

## RFID RC522

**SPI | GPIO 5, 18, 19, 23 | 3.3V ONLY**

> **V1.5 hardware change:** Remove the wire between RC522 RST and GPIO 17. Plug RC522 RST directly into the 3.3V rail instead. RST held HIGH = chip permanently active. RFID works identically. GPIO 17 is now free for the IR door sensor.

| RC522 pin | Connect to | Notes |
|-----------|-----------|-------|
| VCC (3.3V) | 3.3V | Never connect to 5V |
| GND | GND | |
| RST | **3.3V** | V1.5: hardwired HIGH — remove GPIO 17 wire |
| SDA/SS | GPIO 5 | |
| SCK | GPIO 18 | SPI clock |
| MISO | GPIO 19 | SPI data in |
| MOSI | GPIO 23 | SPI data out |
| IRQ | — | Not connected |

---

## IR Obstacle Sensor — Smart Door Lock

**GPIO 17 | Digital | INPUT_PULLUP | V1.5**

| IR sensor pin | Connect to |
|---------------|-----------|
| VCC | 3.3V or 5V (check your module) |
| GND | GND |
| OUT / D0 | GPIO 17 |

Most IR obstacle modules: **LOW = object detected** (door closed in frame), HIGH = clear (door open).

If your module is reversed, tick **"IR sensor inverted"** in web Config tab — no re-flash needed.

> **Safe fail-open:** `INPUT_PULLUP` means if the sensor wire disconnects, GPIO 17 reads HIGH = "door open" = bolt timer permanently frozen. The door stays unlocked and can be opened. A broken sensor never traps someone inside.

---

## 4-Channel Relay Module

**GPIO 15, 16, 25, 33 | Active LOW | 5V**

| Relay IN pin | GPIO | Load |
|-------------|------|------|
| IN1 | 15 | Fan |
| IN2 | 16 | Light |
| IN3 | 25 | Door lock |
| IN4 | 33 | Water pump |

- LOW = relay ON, HIGH = relay OFF
- Remove JD-VCC jumper; power JD-VCC from separate 5V for optical isolation
- Load side: COM → mains Live, NO → device Live

---

## LCD 16×2 with I2C Backpack

**GPIO 21 (SDA) + GPIO 22 (SCL) | I2C | 5V**

| Pin | Connect to |
|-----|-----------|
| VCC | 5V |
| GND | GND |
| SDA | GPIO 21 |
| SCL | GPIO 22 |

Default I2C address: `0x27`. If LCD stays blank, try `0x3F` in firmware. Adjust contrast with the small blue pot on the backpack.

---

## Buttons

| Button | GPIO | Wiring |
|--------|------|--------|
| Exit / Door unlock | 26 | INPUT_PULLUP → GND when pressed |
| LCD page cycle | 35 | 10kΩ pull-DOWN to GND; button → 3.3V when pressed |

> GPIO 35 is input-only — no internal pull-up available. External 10kΩ to GND is required.

---

## Active Buzzer

**GPIO 14 | Direct drive**

| Pin | Connect to |
|-----|-----------|
| + | GPIO 14 |
| − | GND |

HIGH = sounds. Active buzzer sounds on DC — no PWM needed.

---

## Power Summary

| Component | Voltage | Source |
|-----------|---------|--------|
| ESP32 | 5V via VIN | USB charger or PSU |
| HC-SR04 | 5V | 5V rail |
| PIR HC-SR501 | 5V | 5V rail |
| MQ-2 | 5V | 5V rail |
| KY-037 | 5V | 5V rail |
| Relay module VCC | 5V | 5V rail |
| LCD backpack | 5V | 5V rail |
| RFID RC522 | 3.3V | ESP32 3.3V pin |
| DHT11 | 3.3V | ESP32 3.3V pin |
| LDR divider | 3.3V reference | ESP32 3.3V pin |
| Relay load | 230V AC | Mains — isolated by relay |
