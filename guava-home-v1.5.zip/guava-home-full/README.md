# 🍈 Guava Home — ESP32 Smart Home Controller

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform: ESP32](https://img.shields.io/badge/Platform-ESP32-blue.svg)](https://www.espressif.com/en/products/socs/esp32)
[![Arduino IDE](https://img.shields.io/badge/IDE-Arduino-teal.svg)](https://www.arduino.cc/)
[![Version](https://img.shields.io/badge/Version-V1.5-green.svg)](firmware/GuavaHome_V1_5/)

A fully-featured WiFi-connected smart home system built on the ESP32 DevKit V1. Controls fans, lights, a door lock and water pump. Monitors temperature, humidity, motion, soil moisture, gas/smoke and distance. Every setting is configurable from a web browser — no re-flashing needed after initial setup.

---

## ✨ Features

| Feature | Details |
|---------|---------|
| **Sensors** | DHT11, PIR, HC-SR04, LDR, Soil Moisture, MQ-2 Gas, KY-037 Sound |
| **Outputs** | 4 relays (fan, light, door lock, pump), buzzer, LCD 16×2 |
| **Clap Control** | Hardware interrupt — clap to toggle lights instantly |
| **RFID Access** | RC522 reader — 3 configurable user slots, no re-flash |
| **Hotel Door Lock** | IR sensor pauses deadbolt while door is physically open |
| **Telegram Bot** | Remote control + selective alerts from anywhere |
| **Web Dashboard** | PWA — live sensors, relay toggles, full config |
| **OTA Updates** | Flash new firmware over WiFi — no USB after first flash |
| **AP Rescue Mode** | Creates own WiFi if home network unavailable |
| **Pump Auto-Cycle** | Configurable ON/OFF timer for garden watering |
| **100% configurable** | All timings, thresholds, and alerts via web UI |

---

## 📁 Repository Structure

```
guava-home/
├── firmware/
│   ├── GuavaHome_V1_4/
│   │   └── GuavaHome_V1_4.ino    ← Current version (OTA fixed)
│   └── GuavaHome_V1_0/
│       └── GuavaHome_V1_0.ino    ← Baseline release
├── schematics/
│   ├── wiring_diagram.svg         ← Full connection diagram (renders on GitHub)
│   ├── logic_converter_map.md
│   └── power_architecture.md
├── docs/
│   ├── FIRST_BOOT.md
│   ├── TELEGRAM_COMMANDS.md
│   ├── WIRING.md
│   ├── USER_GUIDE.md
│   └── TROUBLESHOOTING.md
├── assets/
│   └── pinout_esp32_devkit_v1.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
└── README.md
```

---

## 🔧 Hardware

### Core Board
- **ESP32 DevKit V1** (38-pin, purple board)

### Sensors

| GPIO | Component | Interface | Notes |
|------|-----------|-----------|-------|
| 4 | DHT11 Temp/Humidity | 1-Wire | 4.7kΩ pull-up to 3.3V |
| 12 | HC-SR04 TRIG | Output | Direct — idles LOW (safe strapping pin) |
| 13 | HC-SR04 ECHO | Input | 5V via 1kΩ/2kΩ voltage divider |
| 27 | PIR HC-SR501 | Digital | 3.3V output — direct |
| 34 | LDR | ADC1 | 10kΩ divider to GND |
| 32 | Soil Moisture AOUT | ADC1 | |
| 36 | MQ-2 Gas AOUT | ADC1 | 5V via 1kΩ/2kΩ voltage divider |
| 39 | KY-037 Sound DO | ISR | FALLING edge, module pull-up |
| 5,18,19,23 | RFID RC522 | SPI | 3.3V only; RST hardwired to 3.3V |
| 17 | IR Obstacle Sensor | Input | V1.5: freed from RFID RST; INPUT_PULLUP |

### Outputs

| GPIO | Device | Notes |
|------|--------|-------|
| 15 | Relay 1 — Fan | Active LOW |
| 16 | Relay 2 — Light | Active LOW |
| 25 | Relay 3 — Door Lock | Active LOW |
| 33 | Relay 4 — Pump | Active LOW |
| 14 | Buzzer | Active buzzer |
| 21/22 | LCD 16×2 SDA/SCL | I2C |
| 2 | Inbuilt LED | Mirrors PIR state |
| 26 | Exit Button | INPUT_PULLUP |
| 35 | LCD Page Button | 10kΩ pull-DOWN |

---

## 🚀 Quick Start

### 1. Install Arduino IDE & ESP32 Core

Add this URL to **File → Preferences → Additional Boards Manager URLs**:
```
https://dl.espressif.com/dl/package_esp32_index.json
```
Install **esp32 by Espressif Systems** via Boards Manager.

### 2. Install Libraries (Sketch → Manage Libraries)

| Library | Author | Note |
|---------|--------|------|
| DHT sensor library | Adafruit | |
| Adafruit Unified Sensor | Adafruit | dependency |
| LiquidCrystal_I2C | Frank de Brabander | |
| UniversalTelegramBot | Brian Lough | |
| ArduinoJson | Benoit Blanchon | **v6.x only — not v7** |
| MFRC522 | GithubCommunity | |

`ArduinoOTA` is built into the ESP32 Arduino core — no install needed.

### 3. Arduino IDE Settings

| Setting | Value |
|---------|-------|
| Board | ESP32 Dev Module |
| Partition Scheme | **Default 4MB with spiffs** |
| CPU Frequency | 240MHz |
| Upload Speed | 115200 |

### 4. First Boot

See **[First Boot Guide →](docs/FIRST_BOOT.md)**

1. Upload firmware via USB
2. ESP32 creates WiFi AP: `Guava_Setup` (no password)
3. Connect phone → `http://192.168.4.1`
4. Config tab → WiFi, Telegram token, Chat ID → Save & Reboot
5. IP shown on LCD and sent via Telegram

### 5. Subsequent OTA Updates

After first USB flash — no cable needed:
- **Arduino IDE:** Tools → Port → Network → `GuavaHome at 192.168.x.x` → Upload
- **Browser:** `http://<IP>/update` → select `.bin` → Upload

Default OTA password: `guavahome` (change in Config tab).

> **If IDE OTA times out:** Telegram's TLS connection can briefly block the loop. Retry the upload immediately — it usually succeeds on the second attempt. Or temporarily raise the Telegram poll interval in Config to reduce blocking frequency.

---

## ⚙️ Configurable Settings

All saved to flash. Survive reboots. No re-flashing needed.

| Setting | Default | Location |
|---------|---------|---------|
| WiFi SSID / Password | — | Config → WiFi |
| Telegram Token / Chat ID | — | Config → WiFi |
| OTA Password | guavahome | Config → OTA |
| Telegram Auto-Status interval | 0 (off) | Config → Telegram |
| Telegram Poll Interval | 8s | Config → Telegram |
| Per-alert toggles (7 types) | all on | Config → Telegram |
| Light Auto-off Delay | 30s | Config → Lighting |
| Fan Auto-ON Temperature | 32°C | Config → Climate |
| Pump ON Duration | 10s | Config → Pump |
| Pump OFF Duration | 50s | Config → Pump |
| Soil Dry Threshold | 3000 ADC | Config → Garden |
| LDR Dark Threshold | 1000 ADC | Config → Advanced |
| Intrusion Alert Distance | 30 cm | Config → Advanced |
| LCD Wake Distance | 80 cm | Config → Advanced |
| LCD Sleep Timer | 30s | Config → Advanced |
| Door Auto-Lock Delay | 3s | Config → RFID |
| RFID Users 1–3 | — | Config → RFID |

---

## 📱 Telegram Commands

```
status          fan_on / fan_off
light_on / light_off   unlock
pump_on / pump_off     pump_auto / pump_stop
mute_on / mute_off     next_page
help            reboot
```

Full reference: **[Telegram Commands →](docs/TELEGRAM_COMMANDS.md)**

---

## 🔔 Automatic Alerts

| Trigger | Alert | Configurable off? |
|---------|-------|-------------------|
| PIR motion | Telegram | ✓ |
| Temp > threshold | Telegram + fan ON | ✓ |
| Soil dry | Telegram + 2 beeps | ✓ |
| Gas/smoke | Telegram + 4 beeps | ✓ |
| Intrusion | Telegram + 3 beeps | ✓ |
| RFID known | Telegram + unlock | ✓ |
| RFID unknown | Telegram + 3 beeps | ✓ |
| Pump auto cycle | Telegram | ✓ |
| Auto-status | Telegram (interval) | ✓ |

---

## 🛡️ Safety Design

- **Relay boot-glitch prevention** — `digitalWrite()` before `pinMode()` in setup
- **PIR warm-up** — 60s ignore period (HC-SR501 stabilisation)
- **OTA suspension** — all relay automation halts during firmware flash
- **AP mode timeout** — rescue WiFi self-destructs after 10 minutes
- **Acoustic debounce** — 1500ms lockout prevents relay-snap echo on clap
- **Pump rest period** — starts in OFF phase, no immediate activation on boot
- **Voltage dividers** — protect GPIO from 5V signals (ECHO, MQ-2)

---

## 📋 Changelog

See **[CHANGELOG.md →](CHANGELOG.md)**

---

## 📄 License

MIT — see [LICENSE](LICENSE)

---

## 🙏 Libraries Used

- [UniversalTelegramBot](https://github.com/witnessmenow/Universal-Arduino-Telegram-Bot) — Brian Lough
- [LiquidCrystal_I2C](https://github.com/johnrickman/LiquidCrystal_I2C) — Frank de Brabander
- [ArduinoJson](https://arduinojson.org/) — Benoit Blanchon
- [MFRC522](https://github.com/miguelbalboa/rfid) — Miguel Balboa
- [DHT sensor library](https://github.com/adafruit/DHT-sensor-library) — Adafruit
